export class Tyre {
    public id;
    public description;
    public stockQuantity;
    public unitPrice;
  

    constructor(){}
    
}