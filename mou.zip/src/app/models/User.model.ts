export class User {
    constructor(
        public id,
        public userName,
        public userPassword
    ) { }
}