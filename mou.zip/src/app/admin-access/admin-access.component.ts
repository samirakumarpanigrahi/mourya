import { Component, OnInit, Type } from '@angular/core';
import * as XLSX from 'xlsx';
import { Tyre } from '../models/Tyre.model';
import { User } from '../models/User.model';
import { TyresService } from '../services/tyres.service';

type AOA = any[][];
@Component({
  selector: 'app-admin-access',
  templateUrl: './admin-access.component.html',
  styleUrls: ['./admin-access.component.css']
})
export class AdminAccessComponent implements OnInit {
  data: AOA;
  wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
  fileName: string = 'SheetJS.xlsx';
  tyre:Tyre;
  tyreArray:Tyre[]=[];



  constructor(private tyreService : TyresService) { }

  ngOnInit(): void {
  }


  onFileChange(evt: any) {
    this.tyreArray=[];
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
      console.log(this.data);
      this.data.forEach((element,index)=>{
        if(index>0){
        this.tyre=new Tyre();


        this.tyre.id=this.getRandomId();
        this.tyre.description=element[0];
        this.tyre.stockQuantity=element[1];
        this.tyre.unitPrice=element[2];
        this.tyreArray.push(this.tyre)
        }
        
      });
      console.log(this.tyreArray);
      
    };
    reader.readAsBinaryString(target.files[0]);
  }


   getRandomId() {
    return Math.floor((Math.random()*6)+1);
}


  Conform(){
    this.tyreService.setTyres(this.tyreArray).subscribe(
      result => {
       console.log(result);
       
      } );
    
  }






}
